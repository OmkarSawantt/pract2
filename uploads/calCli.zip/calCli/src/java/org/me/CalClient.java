/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me;

import java.io.*;
import java.util.Scanner;

/**
 *
 * @author anush
 */
public class CalClient {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        String a;
                
        System.out.println("Enter the Number");
        a = sc.nextLine();
        
        org.me.CalcService_Service service = new org.me.CalcService_Service();
        org.me.CalcService port = service.getCalcServicePort();
        
        System.out.println("Factorial is: " + port.factorial(a));
        
    }
}
