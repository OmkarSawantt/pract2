/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author anush
 */
@WebService(serviceName = "calcService")
public class calcService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "Addition")
    public String add(@WebParam(name = "num1") String txt1, @WebParam(name = "num2") String txt2) {
        int a = Integer.parseInt(txt1);
        int b = Integer.parseInt(txt2);
        return a + b + "";
    }
    @WebMethod(operationName = "Subtraction")
    public String sub(@WebParam(name = "num1") String txt1, @WebParam(name = "num2") String txt2) {
        int a = Integer.parseInt(txt1);
        int b = Integer.parseInt(txt2);
        return a - b + "";
    }
    @WebMethod(operationName = "Multiplication")
    public String mul(@WebParam(name = "num1") String txt1, @WebParam(name = "num2") String txt2) {
        int a = Integer.parseInt(txt1);
        int b = Integer.parseInt(txt2);
        return a * b + "";
    }
    @WebMethod(operationName = "Division")
    public String div(@WebParam(name = "num1") String txt1, @WebParam(name = "num2") String txt2) {
        int a = Integer.parseInt(txt1);
        int b = Integer.parseInt(txt2);
        return a / b + "";
    }
    @WebMethod(operationName = "Factorial")
    public String fact(@WebParam(name = "num1") String txt1) {
        int a = Integer.parseInt(txt1);
        int fact = 1;
        
        for (int i = 2; i<=a; i++) 
            fact *= i;
        return fact + "";
    }
    
}
